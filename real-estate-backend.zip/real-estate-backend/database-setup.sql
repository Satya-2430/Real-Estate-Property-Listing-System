-- Create a new database (if you haven't already)
CREATE DATABASE real_estate_db;

-- Use the new database
USE real_estate_db;

-- Users Table
CREATE TABLE users (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role VARCHAR(50) NOT NULL, -- 'buyer', 'seller', 'agent', 'admin'
    contact_number VARCHAR(50),
    profile_image_url VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Properties Table
CREATE TABLE properties (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    seller_id BIGINT NOT NULL,
    title VARCHAR(255) NOT NULL,
    location VARCHAR(255) NOT NULL,
    price DECIMAL(12, 2) NOT NULL,
    type VARCHAR(50) NOT NULL, -- 'apartment', 'house', 'condo', etc.
    size INT NOT NULL,
    bedrooms INT NOT NULL,
    bathrooms INT NOT NULL,
    status VARCHAR(50) NOT NULL, -- 'for-sale', 'for-rent'
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (seller_id) REFERENCES users(id)
);

-- Property Amenities Table (Many-to-Many): Stores property features
CREATE TABLE property_amenities (
    property_id BIGINT NOT NULL,
    amenity VARCHAR(100) NOT NULL,
    PRIMARY KEY (property_id, amenity),
    FOREIGN KEY (property_id) REFERENCES properties(id) ON DELETE CASCADE
);

-- Property Images Table: Stores URLs for property images
CREATE TABLE property_images (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    property_id BIGINT NOT NULL,
    image_url VARCHAR(255) NOT NULL,
    FOREIGN KEY (property_id) REFERENCES properties(id) ON DELETE CASCADE
);

-- Bookings Table
CREATE TABLE bookings (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    buyer_id BIGINT NOT NULL,
    seller_id BIGINT NOT NULL,
    property_id BIGINT NOT NULL,
    booking_date DATE NOT NULL,
    booking_time TIME NOT NULL,
    status VARCHAR(50) NOT NULL, -- 'pending', 'confirmed', 'cancelled'
    message TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (buyer_id) REFERENCES users(id),
    FOREIGN KEY (seller_id) REFERENCES users(id),
    FOREIGN KEY (property_id) REFERENCES properties(id)
);

-- Inquiries Table
CREATE TABLE inquiries (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT NOT NULL,
    property_id BIGINT NOT NULL,
    message TEXT NOT NULL,
    status VARCHAR(50) DEFAULT 'new', -- 'new', 'replied'
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (property_id) REFERENCES properties(id)
);

-- Inquiry Replies Table
CREATE TABLE inquiry_replies (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    inquiry_id BIGINT NOT NULL,
    user_id BIGINT NOT NULL,
    message TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (inquiry_id) REFERENCES inquiries(id),
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Transactions Table
CREATE TABLE transactions (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    booking_id BIGINT UNIQUE NOT NULL,
    amount DECIMAL(12, 2) NOT NULL,
    payment_status VARCHAR(50) NOT NULL, -- 'pending', 'completed', 'failed'
    payment_method VARCHAR(100),
    transaction_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (booking_id) REFERENCES bookings(id)
);

-- Favorite Properties Table (Many-to-Many)
CREATE TABLE favorite_properties (
    user_id BIGINT NOT NULL,
    property_id BIGINT NOT NULL,
    PRIMARY KEY (user_id, property_id),
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (property_id) REFERENCES properties(id)
);

-- Insert Sample Data
-- Insert Users
-- Note: In a real application, passwords should be hashed!
INSERT INTO users (name, email, password, role, contact_number) VALUES
('Alice Johnson', 'alice@example.com', '$2a$10$...', 'buyer', '123-456-7890'),
('Bob Williams', 'bob@example.com', '$2a$10$...', 'seller', '234-567-8901'),
('Charlie Brown', 'charlie@example.com', '$2a$10$...', 'agent', '345-678-9012'),
('Admin User', 'admin@example.com', '$2a$10$...', 'admin', '456-789-0123');

-- Insert Properties
INSERT INTO properties (seller_id, title, location, price, type, size, bedrooms, bathrooms, status, description) VALUES
(2, 'Modern Downtown Apartment', 'New York, NY', 500000.00, 'apartment', 800, 1, 1, 'for-sale', 'A beautiful and modern apartment in the heart of the city.'),
(2, 'Spacious Suburban House', 'Los Angeles, CA', 750000.00, 'house', 2500, 4, 3, 'for-sale', 'A large house with a big backyard, perfect for a family.'),
(2, 'Cozy Beachfront Condo', 'Miami, FL', 350000.00, 'condo', 1200, 2, 2, 'for-rent', 'Enjoy the ocean view from this cozy condo.');

-- Insert Property Amenities
INSERT INTO property_amenities (property_id, amenity) VALUES
(1, 'Swimming Pool'),
(1, 'Gym'),
(2, 'Garage'),
(2, 'Garden'),
(3, 'Beach Access');

-- Insert Property Images
INSERT INTO property_images (property_id, image_url) VALUES
(1, '/images/cities/new-delhi.jpg'),
(1, '/images/cities/mumbai.jpg'),
(2, '/images/cities/bengaluru.jpg'),
(3, '/images/cities/chennai.jpg');

-- Insert Bookings
INSERT INTO bookings (buyer_id, seller_id, property_id, booking_date, booking_time, status, message) VALUES
(1, 2, 1, '2025-10-15', '14:00:00', 'confirmed', 'Looking forward to seeing the apartment.'),
(1, 2, 2, '2025-10-20', '11:00:00', 'pending', 'I would like to schedule a visit.');

-- Insert Inquiries
INSERT INTO inquiries (user_id, property_id, message, status) VALUES
(1, 3, 'Is the price negotiable?', 'new');

-- Insert Inquiry Replies
INSERT INTO inquiry_replies (inquiry_id, user_id, message) VALUES
(1, 3, 'Yes, we can discuss the price.');

-- Insert Transactions
INSERT INTO transactions (booking_id, amount, payment_status, payment_method) VALUES
(1, 500.00, 'completed', 'Credit Card');

-- Insert Favorite Properties
INSERT INTO favorite_properties (user_id, property_id) VALUES
(1, 2),
(1, 3);