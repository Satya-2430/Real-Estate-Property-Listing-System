# Real Estate Backend Application

A comprehensive Spring Boot backend for a real estate listing application with user management, property listings, bookings, and inquiries.

## Prerequisites

- Java 21 or later
- MySQL 8.0 or later
- Maven 3.6 or later
- Spring Tool Suite (STS) or any Java IDE

## Setup Instructions

### 1. Database Setup

1. Install MySQL and create a database:
   ```sql
   CREATE DATABASE real_estate_db;
   ```

2. Run the SQL script provided in `database-setup.sql` to create tables and insert sample data.

3. Update database credentials in `src/main/resources/application.properties`:
   ```properties
   spring.datasource.username=your_mysql_username
   spring.datasource.password=your_mysql_password
   ```

### 2. Running the Application

1. Open the project in Spring Tool Suite (STS)
2. Right-click on the project → Run As → Spring Boot App
3. The application will start on `http://localhost:8080`

### 3. API Endpoints

#### Authentication
- `POST /api/auth/register` - Register a new user
- `POST /api/auth/login` - User login

#### Properties
- `GET /api/properties` - Get all properties
- `GET /api/properties/{id}` - Get property by ID
- `GET /api/properties/status/{status}` - Get properties by status
- `GET /api/properties/type/{type}` - Get properties by type
- `GET /api/properties/location/{location}` - Search properties by location
- `GET /api/properties/price-range?minPrice=X&maxPrice=Y` - Filter by price range
- `POST /api/properties` - Create new property
- `PUT /api/properties/{id}` - Update property
- `DELETE /api/properties/{id}` - Delete property

#### Users
- `GET /api/users` - Get all users
- `GET /api/users/{id}` - Get user by ID
- `GET /api/users/email/{email}` - Get user by email
- `POST /api/users` - Create user
- `PUT /api/users/{id}` - Update user
- `DELETE /api/users/{id}` - Delete user

#### Bookings
- `GET /api/bookings` - Get all bookings
- `GET /api/bookings/{id}` - Get booking by ID
- `GET /api/bookings/buyer/{buyerId}` - Get bookings by buyer
- `GET /api/bookings/seller/{sellerId}` - Get bookings by seller
- `GET /api/bookings/property/{propertyId}` - Get bookings by property
- `POST /api/bookings` - Create booking
- `PUT /api/bookings/{id}/status?status=X` - Update booking status
- `DELETE /api/bookings/{id}` - Delete booking

#### Inquiries
- `GET /api/inquiries` - Get all inquiries
- `GET /api/inquiries/{id}` - Get inquiry by ID
- `GET /api/inquiries/user/{userId}` - Get inquiries by user
- `GET /api/inquiries/property/{propertyId}` - Get inquiries by property
- `POST /api/inquiries` - Create inquiry
- `PUT /api/inquiries/{id}/status?status=X` - Update inquiry status
- `DELETE /api/inquiries/{id}` - Delete inquiry

### 4. Sample Data

The application includes sample data with:
- 4 users (buyer, seller, agent, admin)
- 3 properties with different types and statuses
- Sample bookings and inquiries
- Property images using local image paths
- Default password for all sample users: "password" (encoded)

### 5. Frontend Integration

To connect your React frontend:

1. Install axios in your React project:
   ```bash
   npm install axios
   ```

2. Update your API calls to use the backend endpoints:
   ```javascript
   // Example: Fetch properties
   const response = await axios.get('http://localhost:8080/api/properties');
   ```

3. The backend is configured with CORS to allow requests from `http://localhost:5173` (Vite default port).

### 6. Security

- Passwords are encrypted using BCrypt
- CORS is configured for frontend integration
- Basic authentication endpoints are provided
- JWT configuration is included but not fully implemented (can be extended)

### 7. Database Schema

The application uses the following main entities:
- **Users**: User accounts with roles (buyer, seller, agent, admin)
- **Properties**: Real estate listings with details and images
- **Bookings**: Property viewing appointments
- **Inquiries**: User questions about properties
- **Transactions**: Payment records for bookings
- **Favorites**: User's favorite properties

## Development Notes

- The application uses Spring Boot 3.2.0 with Java 21
- JPA/Hibernate for database operations
- Lombok for reducing boilerplate code
- MySQL as the database
- Maven for dependency management

## Next Steps

1. Implement JWT authentication for secure API access
2. Add file upload functionality for property images
3. Implement email notifications for bookings and inquiries
4. Add search and filtering capabilities
5. Implement payment gateway integration