package com.example.realestate.service;

import com.example.realestate.model.Property;
import com.example.realestate.repository.PropertyRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class PropertyService {

    @Autowired
    private PropertyRepository propertyRepository;

    public List<Property> getAllProperties() {
        return propertyRepository.findAll();
    }

    public Property getPropertyById(Long id) {
        return propertyRepository.findById(id).orElse(null);
    }
    
    public Property createProperty(Property property) {
        // Here you can add validation or other business logic before saving
        return propertyRepository.save(property);
    }
    
    public void deleteProperty(Long id) {
        propertyRepository.deleteById(id);
    }
}