package com.example.realestate.model;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "favorite_properties")
@Data
public class FavoriteProperty {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;

    @ManyToOne
    @JoinColumn(name = "property_id")
    private Property property;
}