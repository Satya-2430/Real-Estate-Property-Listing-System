package com.example.realestate.model;

import jakarta.persistence.*;
import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "transactions")
@Data
public class Transaction {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne
    @JoinColumn(name = "booking_id", unique = true)
    private Booking booking;

    private BigDecimal amount;
    private String paymentStatus;
    private String paymentMethod;
    
    @Column(updatable = false)
    private LocalDateTime transactionDate = LocalDateTime.now();
}