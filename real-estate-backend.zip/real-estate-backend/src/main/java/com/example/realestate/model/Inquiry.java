package com.example.realestate.model;

import jakarta.persistence.*;
import java.util.List;

@Entity
@Table(name = "inquiries")
public class Inquiry {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;

    @ManyToOne
    @JoinColumn(name = "property_id")
    private Property property;

    private String message;
    private String status;

    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(name = "inquiry_id")
    private List<InquiryReply> replies;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    
    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }
    
    public Property getProperty() { return property; }
    public void setProperty(Property property) { this.property = property; }
    
    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }
    
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    
    public List<InquiryReply> getReplies() { return replies; }
    public void setReplies(List<InquiryReply> replies) { this.replies = replies; }
}