package com.example.realestate.model;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "inquiry_replies")
@Data
public class InquiryReply {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;

    private String message;
}