package com.example.realestate.controller;

import com.example.realestate.model.Inquiry;
import com.example.realestate.service.InquiryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/inquiries")
@CrossOrigin(origins = "http://localhost:5173")
public class InquiryController {

    @Autowired
    private InquiryService inquiryService;

    @GetMapping
    public List<Inquiry> getAllInquiries() {
        return inquiryService.getAllInquiries();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Inquiry> getInquiryById(@PathVariable Long id) {
        return inquiryService.getInquiryById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }



    @GetMapping("/user/{userId}")
    public List<Inquiry> getInquiriesByUser(@PathVariable Long userId) {
        return inquiryService.getInquiriesByUser(userId);
    }

    @GetMapping("/property/{propertyId}")
    public List<Inquiry> getInquiriesByProperty(@PathVariable Long propertyId) {
        return inquiryService.getInquiriesByProperty(propertyId);
    }

    @PostMapping
    public Inquiry createInquiry(@RequestBody Inquiry inquiry) {
        return inquiryService.createInquiry(inquiry);
    }

    @PutMapping("/{id}/status")
    public ResponseEntity<Inquiry> updateInquiryStatus(@PathVariable Long id, @RequestParam String status) {
        try {
            Inquiry updatedInquiry = inquiryService.updateInquiryStatus(id, status);
            return ResponseEntity.ok(updatedInquiry);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteInquiry(@PathVariable Long id) {
        inquiryService.deleteInquiry(id);
        return ResponseEntity.noContent().build();
    }
}